# Python IT Automation

## Overview
A Python-based IT automation project that monitors system health by checking CPU usage, memory usage, and disk space.

## Features
- CPU and memory monitoring
- Disk usage checks
- Automated logging
- Alert notifications (simulated)

## Tech Stack
- Python
- psutil

## How to Run
1. Install dependencies:
   pip install -r requirements.txt
2. Run the application:
   python main.py
