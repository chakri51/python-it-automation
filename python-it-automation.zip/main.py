import json
from src.cpu_memory_check import check_cpu_memory
from src.disk_check import check_disk
from src.log_generator import write_log
from src.email_alert import send_email_alert

with open("config/config.json") as f:
    config = json.load(f)

alerts = []

alerts.extend(check_cpu_memory(config["cpu_threshold"], config["memory_threshold"]))

disk_alert = check_disk(config["disk_threshold"])
if disk_alert:
    alerts.append(disk_alert)

if alerts:
    for alert in alerts:
        write_log(alert, config["log_file"])
    send_email_alert(alerts)
else:
    write_log("System running normally.", config["log_file"])
    print("System status: NORMAL")
