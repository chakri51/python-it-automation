import psutil

def check_disk(disk_threshold):
    if psutil.disk_usage('/').percent > disk_threshold:
        return "High Disk usage detected"
    return None
