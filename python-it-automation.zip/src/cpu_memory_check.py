import psutil

def check_cpu_memory(cpu_threshold, memory_threshold):
    alerts = []
    if psutil.cpu_percent(interval=1) > cpu_threshold:
        alerts.append("High CPU usage detected")
    if psutil.virtual_memory().percent > memory_threshold:
        alerts.append("High Memory usage detected")
    return alerts
