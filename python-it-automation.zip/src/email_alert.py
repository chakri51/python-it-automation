def send_email_alert(alerts):
    print("ALERTS:")
    for alert in alerts:
        print(alert)
