from datetime import datetime

def write_log(message, log_file):
    with open(log_file, "a") as f:
        f.write(f"[{datetime.now()}] {message}\n")
